import React from 'react'
import "./Cart.css"

function Cart() {
  return (
    <div>
      
    </div>
  )
}

export default Cart
