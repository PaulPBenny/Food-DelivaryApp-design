import React from 'react'
import "./PlaceOrder.css"

function PlaceOrder() {
  return (
    <div>
      
    </div>
  )
}

export default PlaceOrder
